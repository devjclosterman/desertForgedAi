const log = document.getElementById('llama-chat-log');
$backend_url = 'http://127.0.0.1:8000/chat'; // Or your actual IP if needed

//$backend_url = 'https://api.desertforgedai.com/chat';  Public domain when deployed


async function sendMessage() {
  const input = document.getElementById('llama-input');
  const text = input.value;
  if (!text) return;
  appendMessage('user', text);
  input.value = '';

  try {
    const res = await fetch('<?php echo $backend_url; ?>', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: text, userId: "demoUser" })
    });
    const data = await res.json();
    appendMessage('bot', data.reply);
  } catch (e) {
    appendMessage('bot', `⚠️ Error: ${e.message}`);
  }
}

function appendMessage(role, text) {
  const div = document.createElement('div');
  div.className = `message ${role}`;
  div.innerText = `${role === 'user' ? 'You' : 'Bot'}: ${text}`;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}
