from fastapi import FastAPI

app = FastAPI()

@app.post("/chat")
def chat(data: dict):
    return {"reply": "You said: " + data["prompt"]}
