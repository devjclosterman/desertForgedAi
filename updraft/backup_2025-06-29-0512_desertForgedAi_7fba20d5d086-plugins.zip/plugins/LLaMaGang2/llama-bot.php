<?php
/*
Plugin Name: LLaMA Bot
Plugin URI: https://yourdomain.com
Description: Chatbot powered by Meta’s LLaMA + Ollama.
Version: 1.0
Author: Desert Forged AI
*/

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('llama-bot-style', plugins_url('llama-bot.css', __FILE__));
    // Comment out the broken .js file
    // wp_enqueue_script('llama-bot-script', plugins_url('llama-bot.js', __FILE__), [], false, true);
});

function llama_bot_shortcode() {
    $api_key = 'kKe_shlLl2UhGQcLVQcQABeD4qPsErZ28EGExXEikCU';  // replace with your key
    $backend_url = 'http://127.0.0.1:8000/chat';  // use live URL when deploying

    ob_start(); ?>
    <div id="llama-bot-container">
        <h3>LLaMA3</h3>
        <div id="llama-chat-log"></div>
        <input type="text" id="llama-input" placeholder="Ask something...">
        <button onclick="sendMessage()">Send</button>
    </div>

    <script>
      const API_KEY = "<?php echo $api_key; ?>";
      const BACKEND_URL = "<?php echo $backend_url; ?>";

      async function sendMessage() {
        const input = document.getElementById('llama-input');
        const text = input.value;
        if (!text) return;
        appendMessage('user', text);
        input.value = '';

        try {
          const res = await fetch(BACKEND_URL, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-api-key': API_KEY
            },
            body: JSON.stringify({ prompt: text, userId: 'demoUser' })
          });

          if (!res.ok) {
            const raw = await res.text();
            appendMessage('bot', `⚠️ Error ${res.status}: ${raw}`);
            return;
          }

          const data = await res.json();
          appendMessage('bot', data.reply);
        } catch (error) {
          appendMessage('bot', `⚠️ Network error: ${error.message}`);
        }
      }

      function appendMessage(role, text) {
        const log = document.getElementById('llama-chat-log');
        const div = document.createElement('div');
        div.className = 'message ' + role;
        div.innerText = (role === 'user' ? 'You' : 'Bot') + ': ' + text;
        log.appendChild(div);
        log.scrollTop = log.scrollHeight;
      }
    </script>
    <?php
    return ob_get_clean();
}

add_shortcode('llama_bot', 'llama_bot_shortcode');
