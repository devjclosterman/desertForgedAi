from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
import sqlite3
from datetime import datetime
import subprocess
import os

app = FastAPI()

API_KEY = os.environ.get("API_KEY") or "changeme"

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def init_db():
    conn = sqlite3.connect("chat_logs.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            user_id TEXT,
            prompt TEXT,
            reply TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def query_ollama(prompt: str) -> str:
    try:
        result = subprocess.run(
            ["ollama", "run", "llama2", prompt],
            capture_output=True,
            text=True,
            timeout=20,
        )
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            return f"Error: {result.stderr.strip()}"
    except Exception as e:
        return f"Exception: {str(e)}"

def verify_api_key(x_api_key: str = Header(None)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.post("/chat")
async def chat(req: Request, x_api_key: str = Header(None)):
    verify_api_key(x_api_key)
    data = await req.json()
    prompt = data.get("prompt", "")
    user_id = data.get("userId", "anonymous")

    reply = query_ollama(prompt)

    conn = sqlite3.connect("chat_logs.db")
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO logs (timestamp, user_id, prompt, reply) VALUES (?, ?, ?, ?)",
        (datetime.utcnow().isoformat(), user_id, prompt, reply)
    )
    conn.commit()
    conn.close()

    return {"reply": reply}
